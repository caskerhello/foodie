-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: foodie
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bookmarks`
--

DROP TABLE IF EXISTS `bookmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookmarks` (
  `bookmarksid` int NOT NULL AUTO_INCREMENT,
  `postid` int DEFAULT NULL,
  `placeid` int DEFAULT NULL,
  `memberid` int DEFAULT NULL,
  PRIMARY KEY (`bookmarksid`),
  KEY `bookmarks_ibfk_1` (`postid`),
  KEY `bookmarks_ibfk_2` (`placeid`),
  KEY `bookmarks_ibfk_3` (`memberid`),
  CONSTRAINT `bookmarks_ibfk_1` FOREIGN KEY (`postid`) REFERENCES `post` (`postid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bookmarks_ibfk_2` FOREIGN KEY (`placeid`) REFERENCES `place` (`placeid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bookmarks_ibfk_3` FOREIGN KEY (`memberid`) REFERENCES `member` (`memberid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookmarks`
--

LOCK TABLES `bookmarks` WRITE;
/*!40000 ALTER TABLE `bookmarks` DISABLE KEYS */;
/*!40000 ALTER TABLE `bookmarks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `images` (
  `imagesid` int NOT NULL AUTO_INCREMENT,
  `postid` int DEFAULT NULL,
  `savefilename` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`imagesid`),
  KEY `images_ibfk_1` (`postid`),
  CONSTRAINT `images_ibfk_1` FOREIGN KEY (`postid`) REFERENCES `post` (`postid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images`
--

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
INSERT INTO `images` VALUES (8,11,'KakaoTalk_20250117_1915009131737165055774.jpg'),(9,11,'KakaoTalk_20250117_191500913_011737165059691.jpg'),(10,11,'KakaoTalk_20250117_191500913_021737165064899.jpg'),(11,12,'KakaoTalk_20250113_1356108321737169307960.jpg'),(12,13,'굴보쌈1737180077901.jpeg'),(13,14,'말차라뗴1737180179389.jpeg'),(14,15,'망고주스1737180380446.jpeg'),(15,16,'돼지국밥1737198435044.jpeg'),(16,17,'버거킹와퍼1737198597964.jpeg');
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `likes`
--

DROP TABLE IF EXISTS `likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `likes` (
  `likesid` int NOT NULL AUTO_INCREMENT,
  `postid` int DEFAULT NULL,
  `memberid` int DEFAULT NULL,
  PRIMARY KEY (`likesid`),
  KEY `likes_ibfk_1` (`postid`),
  KEY `likes_ibfk_2` (`memberid`),
  CONSTRAINT `likes_ibfk_1` FOREIGN KEY (`postid`) REFERENCES `post` (`postid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `likes_ibfk_2` FOREIGN KEY (`memberid`) REFERENCES `member` (`memberid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `likes`
--

LOCK TABLES `likes` WRITE;
/*!40000 ALTER TABLE `likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `memberid` int NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `pwd` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `profileimg` varchar(255) DEFAULT NULL,
  `profilemsg` varchar(255) DEFAULT NULL,
  `snsid` varchar(255) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `zipnum` varchar(45) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'허내강','a','a',NULL,'http://localhost:8070/uploads/KakaoTalk_20250113_1356108321737169307960.jpg','허은우입니다．',NULL,NULL,NULL,NULL),(3,'b','b','b','b','http://localhost:8070/uploads/KakaoTalk_20250117_191500913_021737178946008.jpg',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `place`
--

DROP TABLE IF EXISTS `place`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `place` (
  `placeid` int NOT NULL AUTO_INCREMENT,
  `reviewamount` int DEFAULT NULL,
  `avestars` double DEFAULT NULL,
  `kakaoplaceid` int DEFAULT NULL,
  `category` int DEFAULT NULL,
  `place_name` varchar(255) DEFAULT NULL,
  `road_address_name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `place_url` varchar(255) DEFAULT NULL,
  `x` double DEFAULT NULL,
  `y` double DEFAULT NULL,
  PRIMARY KEY (`placeid`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `place`
--

LOCK TABLES `place` WRITE;
/*!40000 ALTER TABLE `place` DISABLE KEYS */;
INSERT INTO `place` VALUES (1,1,5,1,1,'테스트용','테스트용','010-1111-1111','',37.1,127.1),(13,18,4.947368421052632,835373645,2,'빠리가옥','서울 종로구 수표로28길 33-4','02-6083-1626','http://place.map.kakao.com/835373645',126.9902511859268,37.5732867682917),(14,1,4,10042350,2,'파르투내','서울 중구 마른내로 154','02-2278-7770','http://place.map.kakao.com/10042350',127.005007402647,37.5646113781936),(15,1,3,26980469,1,'굿모닝 삼일대로점','서울 종로구 삼일대로 385-1','02-720-2566','http://place.map.kakao.com/26980469',126.9873132179,37.5690833463602),(16,1,4,9820808,1,'삼해집 종로점','서울 종로구 수표로20길 16-15','02-2273-0266','http://place.map.kakao.com/9820808',126.99091042050365,37.56992520791063),(17,1,3,8430510,5,'스타벅스 인사점','서울 종로구 인사동길 14','1522-3232','http://place.map.kakao.com/8430510',126.98688705882,37.5722187634845),(18,1,4,1069885614,5,'고망고 종로2가점','서울 종로구 삼일대로 390-1','02-2275-2481','http://place.map.kakao.com/1069885614',126.98797421225,37.5694474177344),(19,1,4,1630483489,1,'합천돼지국밥','서울 종로구 삼일대로 418-3','02-742-4142','http://place.map.kakao.com/1630483489',126.98797832774378,37.57201255177833),(20,1,3,20373593,2,'버거킹 종로점','서울 종로구 종로 94','02-2285-4838','http://place.map.kakao.com/20373593',126.9880794053405,37.569935767942724);
/*!40000 ALTER TABLE `place` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post` (
  `postid` int NOT NULL AUTO_INCREMENT,
  `memberid` int DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `writedate` datetime DEFAULT CURRENT_TIMESTAMP,
  `stars` int DEFAULT NULL,
  `placeid` int DEFAULT NULL,
  PRIMARY KEY (`postid`),
  KEY `post_ibfk_1` (`placeid`),
  KEY `post_ibfk_2` (`memberid`),
  CONSTRAINT `post_ibfk_1` FOREIGN KEY (`placeid`) REFERENCES `place` (`placeid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `post_ibfk_2` FOREIGN KEY (`memberid`) REFERENCES `member` (`memberid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (11,1,'샤슬릭 샤샤샤','2025-01-18 10:51:18',4,14),(12,1,'굿모닝은 우리 급식','2025-01-18 12:02:15',3,15),(13,1,'오후 포스팅','2025-01-18 15:01:48',4,16),(14,1,'말차라떼','2025-01-18 15:05:23',3,17),(15,1,'망고주스','2025-01-18 15:06:39',4,18),(16,1,'추울땐 돼지국밥','2025-01-18 20:07:27',4,19),(17,1,'귀찮을땐 와퍼','2025-01-18 20:10:08',3,20);
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reply`
--

DROP TABLE IF EXISTS `reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reply` (
  `replyid` int NOT NULL AUTO_INCREMENT,
  `postid` int DEFAULT NULL,
  `memberid` int DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `writedate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`replyid`),
  KEY `reply_ibfk_1` (`postid`),
  KEY `reply_ibfk_2` (`memberid`),
  CONSTRAINT `reply_ibfk_1` FOREIGN KEY (`postid`) REFERENCES `post` (`postid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reply_ibfk_2` FOREIGN KEY (`memberid`) REFERENCES `member` (`memberid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reply`
--

LOCK TABLES `reply` WRITE;
/*!40000 ALTER TABLE `reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `reply` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-18 23:32:53
